<?php
namespace Softwafop\TeamPVP;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

class Main extends PluginBase implements Listener{


   public function onEnable(){
        if(!is_dir($this->getDataFolder())){
        mkdir($this->getDataFolder());
        }
        $this->team = new Config($this->getDataFolder()."team.yml", Config::YAML,[]);
        }


    public function onCommand(CommandSender $s, Command $cmd, $label, array $args){
        if($cmd->getName() == "team"){
        	if(isset($arg[0])){
        	switch($arg[0]){
        		case "red":
        		$s->sendMessage(TextFormat::RED."Bạn đã vào đội đỏ!");
        		$team = '§c[red]';
        		break;
        		case "blue":
        		$s->sendMessage(TextFormat::BLUE."Bạn đã vào đội xanh!");
        		$team = '§5[blue]';
        		break;
				 case "§eyellow":
				 $s->sendMessage(TextFormat::YELLOW."Bạn đã vào đội vàng!");
				 $team = '§e[yellow]';
				 break;
				 
        		}
        	}
        	$name = $s->getName();
        	$p = $s->getServer()->getPlayer($name);
        	$p->setNametag($team.'§a'.$name);
        	$this->config->set($name,$team);
        	$this->config->save;

        	
        }
    }
	public function onJoin(PlayerJoinEvent $event){
		$p = $event->getPlayer();
		$p->setNametag($team.'§a'.$name);
	}
}